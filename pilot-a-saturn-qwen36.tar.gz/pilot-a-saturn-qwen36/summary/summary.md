# Thực nghiệm A — tổng hợp lượt chạy

Study: `pilot-a-saturn-qwen36`

- Tổng số lượt đã lên lịch: **3**
- Nhóm ghép cặp đủ nhánh và có điểm hợp lệ: **0**
- Nhóm chưa đủ lượt hoặc có lỗi kỹ thuật: **0**
- Lượt smoke test (không đưa vào phân tích ghép cặp/theo loại task): **3**
- Phân loại kết quả đánh giá: `{'fail_test': 3}`

## Kết quả theo lượt

| Task | Nhánh | Seed | Attempt | Agent dừng | Request | Test được cấp | Test được cấp pass | Eval | Reward | F2P | P2P |
|---|---|---:|---|---|---:|---:|---|---|---:|---:|---:|
| adaptix-name-mapping-aliases (smoke_test) | 50-random | 42 | attempt-001 | model_finished | 19 | 678 | pass 678/678 | fail_test | 0 | 0/44 | 2738/2738 |
| adaptix-name-mapping-aliases (smoke_test) | 100 | 42 | attempt-001 | model_finished | 19 | 1356 | pass 1356/1356 | fail_test | 0 | 0/44 | 2738/2738 |
| adaptix-name-mapping-aliases (smoke_test) | 0 | 42 | attempt-001 | model_finished | 18 | 0 | not_applicable 0/0 | fail_test | 0 | 0/44 | 2738/2738 |

## Kết quả theo loại task

| Category | Lượt có điểm hành vi | Reward trung bình | F2P trung bình | P2P trung bình |
|---|---:|---:|---:|---:|
Chưa có lượt thí nghiệm (không phải smoke test) đủ điểm để tổng hợp.

## Các cặp đổi kết quả

Chưa có cặp nhánh hợp lệ nào cho thấy chuyển đổi pass/fail.

Kết quả chi tiết, token usage và lỗi kỹ thuật nằm trong `runs.csv`.
